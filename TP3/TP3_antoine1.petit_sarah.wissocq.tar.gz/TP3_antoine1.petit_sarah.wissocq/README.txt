PETIT Antoine & WISSOCQ Sarah :

Partie Login :
	Actuellement testé :	- création d'un utilisateur

	On ne comprend pas pourquoi le when ne produit pas le résultat attendu