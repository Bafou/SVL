Petit Antoine & Wissocq Sarah

Les deux parties ont été codés en TDD, les deux codes sont par conséquents couvert à 100% (avec tout leurs enbranchements).
Le soucis indiqué la semaine dernière était simplement dû à l'absence d'un return.

Nous avons dès le départ séparé le traitement de l'inscription et de la création de login car pour nous les deux comportements peuvent être sur des services différents.
